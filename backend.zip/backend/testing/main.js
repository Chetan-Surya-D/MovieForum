const other = require('./other');

b = other(9,10);

console.log(b)